% Tutorial_7_1_A.m
%
% Produces an inhibitory stabilized network at high input but not at low
% input, because of the supralinearity (quadratic) firing rate curve.
%
% In this code a single E-unit is coupled with a single I-unit as
% firing-rate models.
%
% This code is a solution of Tutorial 7.1A in the text book:
% An Introductory Course in Computational Neuroscience
% by Paul Miller, Brandeis University, 2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear


dt = 0.0001;            % Time-step for the simulation
tmax = 1;               % Maximum simulation time
tvec = 0:dt:tmax;       % Vector of time points
Nt = length(tvec);      % Number of time points

NE = 1;                 % Number of excitatory units
NI = 1;                 % Number of inhibitory units
Nunits = NE + NI;       % Total network size

%% Now set up the connection matrix
W = zeros(Nunits);      % Define the connection matrix
WEE = 2.0;              % Excitatory-to-excitatory connection
WEI = 2.5;              % Excitatory-to-inhibitory connection
WIE = -2.5;             % Inhibitory-to-excitatory connection
WII = -2.0;             % Inhibitory-to-inhibitory connection

% Fill the values into the matrix
W(1:NE,1:NE) = WEE;     
W(1:NE,NE+1:end) = WEI;
W(NE+1:end,1:NE) = WIE;
W(NE+1:end,NE+1:end) = WII;

%% An applied current for a portion of the trial
stim_on = 0.25;                 % Time of current onset
stim_off = 0.75;                % Time of current offset
n_on = round(stim_on/dt);       % Time-point when current switches on
n_off = round(stim_off/dt);     % Time-point when current switches off

%% Parameters for f-I curves of firing-rate units
alphaE = 0.05;          % Scales the gain of the quadratic curve of E-units
alphaI = 1;             % Scales the gain of the linear curve of I-units
IthreshE = -5;          % Threshold current for rate > 0 (E-units)
IthreshI = 0;          % Threshold current for rate > 0 (I-units)
Ithresh = [ones(NE,1)*IthreshE ; ones(NI,1)*IthreshI]; % Vector of thresholds
rmax = 100;             % Maximum firing rate of all units

%% Now loop through four different parameter sets
for part = 1:4
    
    rvec = zeros(Nunits,Nt);    % Initialize firing-rate vector

    % First default values for input currents and time constants (Part 1)
    tauE = 0.005;               % Time constant (E-units)
    tauI = 0.005;               % Time constant (I-units)
    I0E = 0;                    % Baseline input current (E-units)
    I0I = 0;                    % Baseline input current (I-units)
    I_on_E = 0;                 % Default stimulus current (E-units)
    I_on_I = 20;                % Default stimulus current (I-units)
    
    switch part
        case 2                  % Part 2 -- add extra current
            I0E = 25;           % Baseline input current (E-units)
            I0I = 15;           % Baseline input current (I-units)
            I_on_E = 25;        % Stimulus current (E-units)
            I_on_I = 35;        % Stimulus current (I-units)
            
        case 3                  % Part 3 -- slower tau for I-units
            tauE = 0.002;       % Time constant of E-units
            tauI = 0.010;       % Time constant of I-units

        case 4                  % Part 4 -- extra current + slower tau for I-units            
            I0E = 25;           % Baseline input current (E-units)
            I0I = 15;           % Baseline input current (I-units)
            I_on_E = 25;        % Stimulus current (E-units)
            I_on_I = 35;        % Stimulus current (I-units)
            tauE = 0.002;       % Time constant of E-units
            tauI = 0.010;       % Time constant of I-units
    end

%% Define and set up the matrix of applied currents
    Iapp = [I0E*ones(NE,Nt) ; I0I*ones(NI,Nt) ];    % Baseline values
    Iapp(1:NE,n_on:n_off) = I_on_E;                 % Stimulus to E-unit
    Iapp(NE+1:end,n_on:n_off) = I_on_I;             % Stimulus to I-unit

    
    tauvec = [ones(NE,1)*tauE ; ones(NI,1)*tauI];   % Vector of time constants
    Itot = zeros(Nunits,Nt);                        % Initialize for simulation        
    %% Now start the simulation
    for i = 2:Nt;               % Loop through time points
        % Itot is total current, applied plus feedback
        Itot(:,i) = Iapp(:,i) + W'*rvec(:,i-1);
        
        % Update firing rate of E-units using a quadratic f-I curve, with a
        % 'max' operation so that sub-threshold inputs do not produce 
        % positive rates
        rvec(1:NE,i) = rvec(1:NE,i-1)*(1-dt./tauvec(1:NE)) ...
            + sign(Itot(1:NE,i)-Ithresh(1:NE)) .* ...
        dt*(alphaE*(Itot(1:NE,i)-Ithresh(1:NE)).^2)./tauvec(1:NE);
        
        % Update firing rate of I-units using a linear f-I curve
        rvec(NE+1:end,i) = rvec(NE+1:end,i-1)*(1-dt./tauvec(NE+1:end)) ...
            + dt*alphaI*(Itot(NE+1:end,i)-Ithresh(NE+1:end))./tauvec(NE+1:end);

        rvec(:,i) = min(rvec(:,i),rmax);      % Prevent rates surpassing rmax
        rvec(:,i) = max(rvec(:,i),0);         % Prevent rates decreasing below 0.
    end
    
    %% Now plot the results
    figure(1)
    subplot(2,2,part)
    plot(tvec,rvec);  
    title(strcat('Part ',num2str(part)) )
    xlabel('Time (sec)')
    ylabel('Rate (Hz)')
    legend('rE', 'rI')
    
end