% Tutorial_2_2.m simulates a leaky integrate-and-fire neuron with a
% refractory period that is produced in three different ways. The distinct
% methods (forced voltage clamp; threshold increase; strong refractory
% conductance) are separated out successively below for clarity.
%
% This code is a solution to Tutorial 2.2 in Chapter 2 of the textbook
% An Introductory Course in Computational Neuroscience
% by Paul Miller, Brandeis University, 2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;                      % clear memory of old variables

%% Times to simulate
tmax = 2;                   % maximum time in sec
dt = 0.00001;               % time step in sec
t = 0:dt:tmax;              % vector of time points
ton = 0;                    % time to start applied current
toff = tmax;                % time to stop applied current
non = round(ton/dt)+1;      % time point the current starts
noff = round(toff/dt);      % time point the current stops

%% Basic parameters
E_L = -0.070;               % Leak potential
Vth0 = -0.050;              % Threshold baseline
Vreset = -0.065;            % Reset potential
E_K = -0.080;               % Potassium reversal
Vpeak = 0.050;              % Draw a spike
Cm = 100e-12;               % Membrane capacitance
Rm = 100e6;                 % Membrane resistance
G_L = 1/Rm;                 % Membrane (leak) conductance

t_ref = 0.0025;             % Clamped refractory period

Iapp = [100:20:600]*1e-12;  % Set of applied currents to use

%% Default plotting parameters
%  Next line sets the fonts to be used in plots
set(0,'DefaultLineLineWidth',2,...
    'DefaultLineMarkerSize',8, ...
    'DefaultAxesLineWidth',2, ...
    'DefaultAxesFontSize',14,...
    'DefaultAxesFontWeight','Bold');
% Next 6 lines clear the three figures to start fresh.
figure(1)
clf
figure(2)
clf
figure(3)
clf


%% First simulate using method 1, with V clamped to Vreset for the
%  refractory period of duration tref.

Ntrials = length(Iapp);             % Number of different applied currents
meanV1 = zeros(size(Iapp));         % To store mean membrane potential
rate1 = zeros(size(Iapp));          % To store firing rate
Vth = Vth0;

for trial = 1:Ntrials;              % Now loop through trials
    I = zeros(size(t));             % Initialize applied current to zero
    I(non:noff) = Iapp(trial)*ones(1,noff+1-non); % except when current is on
    V = E_L*ones(size(t));          % Initialize membrane potential to leak
    spikes = zeros(size(t));        % Initalize spike array to zero
    last_spiketime = -2*t_ref;      % Initialize time of last spike to the past
 
    for i = 2:length(t);            % Loop through time points
        if ( t(i) > last_spiketime + t_ref ) % If refractory period is over
            V(i) = V(i-1) + dt*(I(i) +G_L*(E_L-V(i-1)))/Cm;   % Integrate V
        else
            V(i) = Vreset;                    % Otherwise clamp V to Vreset
        end
        
        if ( V(i) > Vth )           % If Vm is above threshold
            spikes(i) = 1;          % A spike is recorded
            V(i-1) = Vpeak;         % Not used in the simulation but for plotting
            V(i) = Vreset;          % Reset the current membrane potential
            last_spiketime = t(i);  % Record as the time of last spike
        end
    end;                            % End of time loop
    
    meanV1(trial) = mean(V);        % Record the mean membrane potential
    rate1(trial) = sum(spikes)/tmax; % Record the firing rate
    %% Plot a section of the membrane potential trace for a low firing rate 
    %  and for a high firing rate.
    
    if ( Iapp(trial) == 220e-12 )   % Current for low rate
        figure(4)                   
        clf;                        % Clear the figure
        hold on;                    % Now allow multiple plots
        plot(t,V*1000)              % Converting Vm t   o mV
        axis([0.1 0.2 -80 0])       % Just show 100ms
        xlabel('Time (sec)')        
        ylabel('Membrane potential (mV)')
    end
    
    if ( Iapp(trial) == 500e-12 )   % Current for high rate
        figure(4)   
        hold on;                    % Don't erase old plot
        plot(t,V*1000,'r')          % Use mV and plot in red
    end
end;                                % End of loop through applied currents

%% Plot summary data for first method.

figure(1)
plot(Iapp,meanV1)                   % Mean Vm vs applied current
hold on;                            % Don't erase later

figure(2)
plot(Iapp,rate1)                    % Mean rate vs applied current
hold on;                            % Don't erase later

figure(3)           
plot(rate1,meanV1)                  % Mean Vm versus mean rate
hold on;                            % Don't erase later


%% Next simulate using method 2, with instantaneous reset combined with a
%  jump in threshold following each spike, that decays over a time t_ref.

meanV2 = zeros(size(Iapp));         % To store mean membrane potential (Method 2)
rate2 = zeros(size(Iapp));          % To store firing rate (Method 2)
Vth_max = 200e-3;                   % Threshold value after a spike
tau_Vth = 1e-3;                     % Decay time constant for threshold

for trial = 1:Ntrials;              % Now loop through trials
    I = zeros(size(t));             % Initialize applied current to zero
    I(non:noff) = Iapp(trial)*ones(1,noff+1-non); % except when current is on
    V = E_L*ones(size(t));          % Initialize membrane potential to leak
    spikes = zeros(size(t));        % Initalize spike array to zero
    Vth = Vth0*ones(size(t));       % Initialize a vector for the threshold
 
    for i = 2:length(t)             % Now loop through time points
        V(i) = V(i-1) + ...                              % Integrate V
            dt*(I(i) +G_L*(E_L-V(i-1)))/Cm;
        Vth(i) = Vth(i-1) + (Vth0-Vth(i-1))*dt/tau_Vth;  % Integrate Vth

        if ( V(i) > Vth(i) )        % If there is a spike
            spikes(i) = 1;          % Record spike time
            V(i-1) = Vpeak;         % Does not affect simulation: for plotting use
            V(i) = Vreset;          % Reset membrane potential
            Vth(i) = Vth_max;       % Set threshold to maximum
        end
    end;                            % End time loop
    
    meanV2(trial) = mean(V);        % Record mean Vm
    rate2(trial) = sum(spikes)/tmax;    % Record mean rate
    %% Plot a section of the membrane potential trace for a low firing rate 
    %  and for a high firing rate.
    
    if ( Iapp(trial) == 220e-12 )   % Current for low rate
        figure(5)                   
        clf;                        % Clear the figure
        hold on;                    % Now allow multiple plots
        plot(t,V*1000)              % Converting Vm t   o mV
        axis([0.1 0.2 -80 0])       % Just show 100ms
        xlabel('Time (sec)')        
        ylabel('Membrane potential (mV)')
    end
    
    if ( Iapp(trial) == 500e-12 )   % Current for high rate
        figure(5)   
        hold on;                    % Don't erase old plot
        plot(t,V*1000,'r')          % Use mV and plot in red
    end

end

figure(1)
plot(Iapp,meanV2,':')               % Mean of Vm versus applied current
hold on;                            % Don't erase by overwriting

figure(2)
plot(Iapp,rate2,':')                % Spike rate versus applied current
hold on;                            % Don't erase by overwriting

figure(3)
plot(rate2,meanV2,':')              % Mean of Vm versus spike rate
hold on;                            % Don't erase by overwriting


%% Next simulate using method 3, with a refractory conductance that decays
%  with a time constant of t_ref combined with threshold increase.

meanV3 = zeros(size(Iapp));         % New vector for mean of Vm (Method 3)
rate3 = zeros(size(Iapp));          % New vector for spike rate (Method 3)

delta_G = 2e-6;                     % Increment in Gref per spike
tau_Gref = 0.2e-3;                  % Decay time constant for Gref

for trial = 1:Ntrials;              % Loop through applied currents
    I = zeros(size(t));             % Initialize applied current to zero
    I(non:noff) = Iapp(trial)*ones(1,noff+1-non); % except when current is on
    V = E_L*ones(size(t));          % Initialize membrane potential to leak
    spikes = zeros(size(t));        % Initalize spike array to zero
    Vth = Vth0*ones(size(t));       % Initialize a vector for the threshold
    G_ref = zeros(size(t));         % Initialize a vector of zeros for Gref
    
    for i = 2:length(t)             % Loop through time points
        G_ref(i) = G_ref(i-1)*(1-dt/tau_Gref);  % Exponential decay of G_ref
        Vth(i) = Vth(i-1) + (Vth0-Vth(i-1))*dt/tau_Vth;  % Integrate Vth

        V(i) = V(i-1) + ...                              % Integrate V
            dt*(I(i) +G_L*(E_L-V(i-1)) +G_ref(i)*(E_K-V(i-1)) )/Cm;
        
        if ( V(i) > Vth(i) )        % If Vm is above threshold
            spikes(i) = 1;          % Record a spike
            V(i-1) = Vpeak;         % Does not affect simulation but plots a spike
            Vth(i) = Vth_max;       % Set threshold to maximum
            G_ref(i) = G_ref(i) + delta_G;  % Increment Gref at each spike time
        end
    end;                            % End time loop
    
    meanV3(trial) = mean(V);        % Record mean membrane potential
    rate3(trial) = sum(spikes)/tmax; % Record spike rate

    %% Plot a section of the membrane potential trace for a low firing rate 
    %  and for a high firing rate.
    
    if ( Iapp(trial) == 220e-12 )   % Current for low rate
        figure(6)                   
        clf;                        % Clear the figure
        hold on;                    % Now allow multiple plots
        plot(t,V*1000)              % Converting Vm t   o mV
        axis([0.1 0.2 -80 0])       % Just show 100ms
        xlabel('Time (sec)')        
        ylabel('Membrane potential (mV)')
    end
    
    if ( Iapp(trial) == 500e-12 )   % Current for high rate
        figure(6)   
        hold on;                    % Don't erase old plot
        plot(t,V*1000,'r')          % Use mV and plot in red
    end

end

figure(1)
plot(Iapp,meanV3,'--')              % Plot mean Vm versus applied current
hold on;                            % Don't erase by overwriting
xlabel('Applied Current (A)')
ylabel('Mean V')

figure(2)
plot(Iapp,rate3,'--')               % Plot spike rate versus applied current
hold on;                            % Don't erase by overwriting
xlabel('Applied Current (A)')
ylabel('Firing Rate (Hz)')

figure(3)
plot(rate3,meanV3,'--')             % Plot mean Vm versus spike rate
hold on;                            % Don't erase by overwriting
xlabel('Firing Rate (Hz)')
ylabel('Mean V')

