% Tutorial_7_1_B.m
%
% Produces an inhibitory stabilized network at high input but not at low
% input, because of the supralinearity (quadratic) firing rate curve.
%
% In this code two pairs of E-unit coupled to I-unit are connected with
% cross-inhibition to produce a bistable system with low "up-state" rates.
%
% This code is a solution of Tutorial 7.1B in the text book:
% An Introductory Course in Computational Neuroscience
% by Paul Miller, Brandeis University, 2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
close all

dt = 0.0001;            % Time-step for the simulation
tmax = 4;               % Maximum simulation time
tvec = 0:dt:tmax;       % Vector of time points
Nt = length(tvec);      % Number of time points

NE = 2;                 % Number of excitatory units
NI = 2;                 % Number of inhibitory units
Nunits = NE + NI;       % Total network size

%% Now set up the connection matrix
W = zeros(Nunits);      % Define the connection matrix
% First within paired E-I unit connections
WEE = 2.0;              % Excitatory-to-excitatory connection
WEI = 2.5;              % Excitatory-to-inhibitory connection
WIE = -2.5;             % Inhibitory-to-excitatory connection
WII = -2.0;             % Inhibitory-to-inhibitory connection
% Then between E-I unit connections
WEEx = 0.0;             % E-to-E cross-connections
WEIx = 1.75;             % E-to-I cross-connections
WIEx = 0.0;             % I-to-E cross-connections
WIIx = 0.0;             % I-to-I cross-connections

% Fill the values into the connection matrix
W(1:NE,1:NE) = WEEx;
W(1:NE,NE+1:end) = WEIx;
W(NE+1:end,1:NE) = WIEx;
W(NE+1:end,NE+1:end) = WIIx;
for i = 1:NE
    W(i,i) = WEE;
    W(i,i+NE) = WEI;
    W(i+NE,i) = WIE;
    W(i+NE,i+NE) = WII;
end

%% Applied currents for two portion of the trial
stim_on1 = 1.0;                 % Time of current onset
stim_off1 = 1.1;                % Time of current offset
stim_on2 = 2.0;                 % Time of current onset
stim_off2 = 2.1;                % Time of current offset
n_on1 = round(stim_on1/dt);       % Time-point when current switches on
n_off1 = round(stim_off1/dt);     % Time-point when current switches off
n_on2 = round(stim_on2/dt);       % Time-point when current switches on
n_off2 = round(stim_off2/dt);     % Time-point when current switches off

I_on_E = 10;              % Transient applied current to one E-unit
I_on_I = 0;               % Transient applied current to one I-unit

%% Parameters for f-I curves of firing-rate units
alphaE = 0.05;          % Scales the gain of the quadratic curve of E-units
alphaI = 1;             % Scales the gain of the linear curve of I-units
IthreshE = -5;          % Threshold current for rate > 0 (E-units)
IthreshI = 0;          % Threshold current for rate > 0 (I-units)
Ithresh = [ones(NE,1)*IthreshE ; ones(NI,1)*IthreshI]; % Vector of thresholds
rmax = 100;             % Maximum firing rate of all units


rvec = zeros(Nunits,Nt);    % Initialize firing-rate vector

% First default values for input currents and time constants (Part 1)
tauE = 0.005;               % Time constant (E-units)
tauI = 0.005;               % Time constant (I-units)
I0E = 25;                    % Baseline input current (E-units)
I0I = 20;                    % Baseline input current (I-units)

%% Define and set up the matrix of applied currents
Iapp = [I0E*ones(NE,Nt) ; I0I*ones(NI,Nt) ];    % Baseline values
Iapp(1,n_on1:n_off1) = I_on_E;                  % First stimulus is to 1st E-unit
Iapp(NE+1,n_on1:n_off1) = I_on_I;               % First stimulus is to 1st I-unit
Iapp(2,n_on2:n_off2) = I_on_E;                  % Second stimulus is to 2nd E-unit
Iapp(NE+2,n_on2:n_off2) = I_on_I;               % Second stimulus is to 2nd I-unit

tauvec = [ones(NE,1)*tauE ; ones(NI,1)*tauI];   % Vector of time constants
Itot = zeros(Nunits,Nt);                        % Initialize for simulation
rvec(2,1) = 0.01;                               % Break symmetry to start simulation
%% Now start the simulation
for i = 2:Nt;               % Loop through time points
    % Itot is total current, applied plus feedback
    Itot(:,i) = Iapp(:,i) + W'*rvec(:,i-1);
    
    % Update firing rate of E-units using a quadratic f-I curve, with a
    % 'max' operation so that sub-threshold inputs do not produce
    % positive rates
    rvec(1:NE,i) = rvec(1:NE,i-1).*(1-dt./tauvec(1:NE)) ...
        + sign(Itot(1:NE,i)-Ithresh(1:NE)) .* ...
        dt.*(alphaE.*(Itot(1:NE,i)-Ithresh(1:NE)).^2)./tauvec(1:NE);
    
    % Update firing rate of I-units using a linear f-I curve
    rvec(NE+1:end,i) = rvec(NE+1:end,i-1).*(1-dt./tauvec(NE+1:end)) ...
        + dt*alphaI*(Itot(NE+1:end,i)-Ithresh(NE+1:end))./tauvec(NE+1:end);
    
    rvec = min(rvec,rmax);      % Prevent rates surpassing rmax
    rvec = max(rvec,0);         % Prevent rates decreasing below 0.

end

%% Now plot the results
figure(1)
clf
plot(tvec,rvec);
xlabel('Time (sec)')
ylabel('Firing Rate (Hz)')
legend('rE(1)', 'rE(2)', 'rI(1)', 'rI(2)')

