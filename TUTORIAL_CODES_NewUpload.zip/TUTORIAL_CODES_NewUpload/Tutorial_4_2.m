% Tutorial_4_2.m
%
% Code for solving Tutorial 4.2 from the textbook
% An Introductory Course in Computational Neuroscience
% by Paul Miller, Brandeis University (February 2017)
%
% The code uses a function, PIR, which simulates a model of the thalamic
% relay neuron with a T-type calcium conductance to produce a rebound based
% on disinhibition of the T-type channels.
%
% The goal of the tutorial is to run a series of simulations with a range
% of baseline currents and step-increase currents, then to caclulate the 
% minimum ISI and the number of spikes during the step.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear
close all

I_base = -200e-12:25e-12:200e-12;   % Baseline current before and after step
I_step = 0:10e-12:100e-12;          % Temporary additional step current

N_base = length(I_base);            % Number of base current values
N_steps = length(I_step);           % Number of stepped current values

min_ISI = ones(N_base,N_steps);     % Array for minimum ISIs
Nspikes = zeros(N_base,N_steps);    % Array for counting spikes

dt = 5e-6;                          % Time-step for simulation
non = round(0.25/dt);               % Time index to step up current
noff = round(0.5/dt);               % Time index to step back down current

for i = 1:N_base;                   % Loop through set of baseline curents
    I0 = I_base(i);                 % Set baseline current
    for j = 1:N_steps;              % Loop through values of current step
        I_add = I_step(j);          % Set the additional current for the step
        [V t] = PIR(I0,I_add,dt);   % Simulate the PIR model with these currents
        spikes = zeros(size(t));    % To store the number of spikes
        in_spike = 0;               % Start with no spike counted
        for index = non:noff;       % Loop through period of current step
            if ( V(index) > 0 )     % If membrane potential is high
                if (in_spike == 0 ) % and neuron was not recorded as in a spike
                    in_spike = 1;   % set neuron to be in a spike
                    spikes(index) = 1;  % record the spike at this time-point
                end
            else
                if ( in_spike == 1 )    % If a spike is being recorded
                    if ( V(index) < -0.040 )    % And the membrane potential is low
                        in_spike = 0;   % End the record of being in a spike
                    end
                end
            end
        end
                    
        Nspikes(i,j) = sum(spikes);     % Total number of spikes in the step
        if ( Nspikes(i,j) > 1 )         % If there are 2 or more spikes
            ISIs = dt*diff(find(spikes));   % Calculate the ISIs
            min_ISI(i,j) = min(ISIs);   % amd find the minimum
        end            
            
    end;                            % Next value of current step
end;                                % Next value of baseline current
  
figure(1)
imagesc(Nspikes')                   % Plot the array of total spikes
set(gca,'YDir','normal')

colorbar
title('Number of Spikes')
xlabel('Base Current')
ylabel('Current increase')

figure(2)
imagesc(1./min_ISI')                % Plot the array of smallest ISIs
set(gca,'YDir','normal')

colorbar
title('Max Rate')
xlabel('Base Current')
ylabel('Current increase')

